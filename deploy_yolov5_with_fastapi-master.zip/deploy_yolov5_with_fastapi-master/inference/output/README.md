this is a output img dir.
