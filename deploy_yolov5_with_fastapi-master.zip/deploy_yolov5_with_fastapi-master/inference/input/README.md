this is a input img dir.
